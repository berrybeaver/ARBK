/*
 * Andreas Welly Octavianus_3541951_ARBKVS_Praktikum4.c
 *
 * Created: 09.11.2023 13:46:39
 * Author : welly
 */ 

#include "keys.h"
#include "sevenseg.h"


volatile uint32_t systemClock=0;
volatile uint32_t count = 0;
// 
// ISR(INT0_vect) { // SW1
// 	if (count == 0) {
// 		count = 99;
// 		} else {
// 		count--;
// 	}
// }
// 
// ISR(INT1_vect) { // SW2
// 	if (count == 99) {
// 		count = 0;
// 		} else {
// 		count++;
// 	}
// }
ISR(PCINT0_vect){														//Interrupt Routine
	if(!(PINB & (1<<PINB1))){											//if SW1 pressed
		if(count == 0){
			count =99;
			}else{
			count--;;
		}
	}
	if(!(PINB & (1<<PINB2))){											//if SW2 pressed
		if(count == 99){
			count =0;
			}else{
			count++;
		}
	}
}
/*
	PB0 = a
	PB1 = b
	PB2 = c
	PB3 = d
	PB4 = e
	PB5 = f
	PD0 = g
	PD1 = A
 */
// void init(){
// 	DDRD = 0b00001100; // PD2 & PD3 as input, PD0 & PD 1 as output
// 	PORTD |= (1 << PIND2) | (1 << PIND3); // Enable pull-up resistors for PD2&PD3
// 	PORTD = 0x00;
// 	DDRB = 0xff; // PB as output
// }
void init(){
	DDRD=0xff;															//PORTD as output
	PORTD=0x00;														
	
	DDRB = 0x01;														//PINB 0 as input and the rest are output
	PORTB = (1<<PINB1)|(1<<PINB2);
}
	
int main(void)
{
	init();
	init_interrupt();
    while (1) 
    {
		int y = count%10;
		int x = count/10; 
		out(y);
		out(x);
		//_delay_ms(200);
    }
}

ISR(TIMER0_COMPA_vect){
	systemClock++;		//system clock +1 every ms
}


