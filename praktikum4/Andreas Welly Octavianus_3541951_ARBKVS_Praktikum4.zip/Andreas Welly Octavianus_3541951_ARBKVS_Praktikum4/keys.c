/*
 * keys.c
 *
 * Created: 09.11.2023 13:59:34
 *  Author: welly
 */ 
#include "keys.h"

void init_interrupt(){
	cli();
	PCICR = (1<<PCIE0);
	PCMSK0=(1<<PINB1)|(1<<PINB2);
	/*timer*/
	TCCR0A = (1<<WGM01); //set CTC(clear timer on compare match) bit
	TCCR0B = (1<<CS00)|(1<<CS01); //prescaler als 64
	OCR0A = 249;		//um 1ms zu erreichen braucht man 250 Ticks in 64 prescale
	TIMSK0 = (1<<OCIE0A);	//Set to use OCR0A as comparison
	sei();
}

// void init_interrupt(){
// 	cli();							//clear interrupt flag
// 	EICRA = (1<<ISC11)|(1<<ISC01);	//set the control on INT0 & INT1 to falling edge->generate interrupt
// 	EIMSK = (1<<INT0)|(1<<INT1);	//enable external interrupt from INT0&INT1
// 	sei();							//set global interrupt flag
// }

